# a testsuite that will force failure - for testing purposes

run()
{
	run_testcase false
}

